import OpenAI from "openai";
import type { ChatMessage, ChatCompletionResult } from "./types";

export interface OpenRouterChatCompletionRequest {
  model: string;
  messages: ChatMessage[];
  maxTokens?: number;
  timeoutMs?: number;
}

export async function createOpenRouterChatCompletion(
  request: OpenRouterChatCompletionRequest
): Promise<ChatCompletionResult> {
  // Using Replit's AI Integrations service for OpenRouter access
  const baseURL = process.env.AI_INTEGRATIONS_OPENROUTER_BASE_URL;
  const apiKey = process.env.AI_INTEGRATIONS_OPENROUTER_API_KEY;
  
  if (!baseURL || !apiKey) {
    throw new Error("Replit AI Integration for OpenRouter not configured");
  }

  try {
    const timeoutMs = request.timeoutMs || 90000;
    const startTime = Date.now();
    
    const client = new OpenAI({
      baseURL: baseURL,
      apiKey: apiKey,
      timeout: timeoutMs,
    });

    // Use streaming to measure TTFT (Time to First Token)
    const stream = await client.chat.completions.create({
      model: request.model,
      messages: request.messages,
      max_tokens: request.maxTokens || 4096,
      stream: true,
    });

    let ttftMs = 0;
    let content = "";
    let firstChunkReceived = false;
    
    for await (const chunk of stream) {
      if (!firstChunkReceived) {
        ttftMs = Date.now() - startTime;
        firstChunkReceived = true;
        console.log(`[OpenRouter] ${request.model} TTFT: ${ttftMs}ms`);
      }
      
      const delta = chunk.choices[0]?.delta?.content || "";
      content += delta;
    }
    
    // Estimate tokens (streaming doesn't provide usage in chunks)
    const inputTokens = Math.ceil(request.messages.reduce((sum, m) => sum + m.content.length, 0) / 4);
    const outputTokens = Math.ceil(content.length / 4);
    
    const totalTimeMs = Date.now() - startTime;
    const tokensPerSecond = totalTimeMs > 0 ? Math.round((outputTokens / (totalTimeMs / 1000))) : 0;
    
    console.log(`[OpenRouter] Model: ${request.model}, TTFT: ${ttftMs}ms, Total: ${totalTimeMs}ms, tokens: ${inputTokens}/${outputTokens}, throughput: ${tokensPerSecond} tok/s`);

    return {
      content,
      inputTokens,
      outputTokens,
      responseTimeMs: ttftMs,
      totalTimeMs,
      tokensPerSecond,
    };
  } catch (error: any) {
    console.error("OpenRouter API error:", error);
    
    if (error.message?.includes("timed out") || error.message?.includes("timeout")) {
      throw new Error("⏱️ Response timed out (query too complex)");
    }
    
    throw new Error(`Failed to get OpenRouter response: ${error.message}`);
  }
}

export const KIMI_K2_MODEL_ID = "moonshotai/kimi-k2";
export const QWEN3_14B_MODEL_ID = "qwen/qwen3-14b";
